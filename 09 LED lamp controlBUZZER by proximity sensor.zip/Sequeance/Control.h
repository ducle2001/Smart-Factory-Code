#ifndef Con
#define Con
extern char cmd_index;
extern boolean manual;

#define SEC 700
#endif
